//music loading animation
music.onload = function(){
    document.getElementById("bandcamp-loader").style.display='none';
}